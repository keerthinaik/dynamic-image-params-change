package com.example.imageadjust;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.SeekBar;

public class MainActivity extends AppCompatActivity {

    int mBrightness = 0;
    int mContrast = 0;
    int mBlackLevel = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Drawable drawable = ContextCompat.getDrawable(this, R.drawable.scenery);
        final Bitmap bitmap = BitmapFactory.decodeResource(getApplicationContext().getResources(),
                R.drawable.scenery);
        final ImageView imageView = findViewById(R.id.imageview);

        SeekBar brightnessSeekBar = findViewById(R.id.seekbar1);
        brightnessSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
//                imageView.setColorFilter(setBrightness(progress));
//                drawable.setColorFilter(setBrightness(progress));
//                imageView.setImageDrawable(drawable);
                mBrightness = progress;
                Bitmap newBitmap = changeBitmapContrastBrightness(bitmap, mContrast, mBrightness, mBlackLevel);
                Drawable newDrawable = new BitmapDrawable(getResources(), newBitmap);
                imageView.setImageDrawable(newDrawable);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        SeekBar contrastSeekBar = findViewById(R.id.seekbar2);
        contrastSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
//                imageView.setColorFilter(setContrast(progress));
//                drawable.setColorFilter(setContrast(progress));
//                imageView.setImageDrawable(drawable);
                mContrast = progress;
                Bitmap newBitmap = changeBitmapContrastBrightness(bitmap, mContrast,mBrightness, mBlackLevel);
                Drawable newDrawable = new BitmapDrawable(getResources(), newBitmap);
                imageView.setImageDrawable(newDrawable);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        SeekBar blackLevelSeekBar = findViewById(R.id.seekbar3);
        blackLevelSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
//                imageView.setColorFilter(setBlackLevel(progress));
//                drawable.setColorFilter(setBlackLevel(progress));
//                imageView.setImageDrawable(drawable);
                mBlackLevel = progress;
                Bitmap newBitmap = changeBitmapContrastBrightness(bitmap, mContrast,mBrightness, mBlackLevel);
                Drawable newDrawable = new BitmapDrawable(getResources(), newBitmap);
                imageView.setImageDrawable(newDrawable);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });



    }

    public static PorterDuffColorFilter setBrightness(int progress) {
        /*if (progress >= 100){
            int value = (int) (progress - 100) * 255/100;
            return new PorterDuffColorFilter(Color.argb(value,255,255,255), PorterDuff.Mode.SRC_OVER);
        }
        else {
            int value = (int) (100 - progress) * 255 / 100;
            return new PorterDuffColorFilter(Color.argb(value, 0, 0, 0), PorterDuff.Mode.SRC_ATOP);
        }*/
        int value = (int) (progress * 2.55);
        return new PorterDuffColorFilter(Color.rgb(value, value, value), PorterDuff.Mode.ADD);
    }

    public static PorterDuffColorFilter setContrast(int progress) {
        int value = (int) (progress * 2.55);
        return new PorterDuffColorFilter(Color.argb(value, 0, 0, 0), PorterDuff.Mode.OVERLAY);
    }

    public static PorterDuffColorFilter setBlackLevel(int progress) {
        int value = 255 - (int) (progress * 2.55);
        return new PorterDuffColorFilter(Color.rgb(value,value,value), PorterDuff.Mode.MULTIPLY);
    }

    /**
     * Method that accepts brightness, contrast, black level of range 0 to 100.
     * @param bmp input bitmap
     * @param contrast 0..10 1 is default
     * @param brightness -255..255 0 is default
     * @param blackLevel 0..1 1 is default
     * @return new bitmap
     */
    public static Bitmap changeBitmapContrastBrightness(Bitmap bmp, float contrast, float brightness, float blackLevel) {
        contrast = contrast / 10;
        brightness = (brightness * 5.12f) - 255;
        blackLevel = blackLevel / 100;
        ColorMatrix cm = new ColorMatrix(new float[]
                {
                        contrast, 0, 0, 0, brightness,
                        0, contrast, 0, 0, brightness,
                        0, 0, contrast, 0, brightness,
                        0, 0, 0, blackLevel, 0
                });

        Bitmap ret = Bitmap.createBitmap(bmp.getWidth(), bmp.getHeight(), bmp.getConfig());

        Canvas canvas = new Canvas(ret);

        Paint paint = new Paint();
        paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawBitmap(bmp, 0, 0, paint);

        return ret;
    }
}